package com.example.modelandview.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.modelandview.Friend;

@Controller
public class FriendController {
	
	@GetMapping("/index")
	
	public String friendlist() {
		return "friendlist";
	}
	@RequestMapping(value = "/saveFriend", method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute Friend friend) {
		System.out.println(friend);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject(friend);
		return modelAndView;
	}

	//th:object="${friend}" HTML???
}
