package com.example.modelandview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelandviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelandviewApplication.class, args);
	}

}
